#!/bin/bash
java -jar fastabreaker-jfx.jar
